let num = Number (prompt("Ingrese su edad, para comprobar que ud es mayor de edad"));
if (num >= 18){
    alert("BIENVENIDO")
}else if (num < 18){
    alert("NO PUEDES INGRESAR PORQUE NO CUMPLES CON LOS REQUISITOS")
}