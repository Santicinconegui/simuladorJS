//let nombreApellido = "santiago cinconegui"
  
let nombreApellido = prompt('ingrese su nombre')
console.log(nombreApellido)
alert('bienvenido! ' +  nombreApellido)

